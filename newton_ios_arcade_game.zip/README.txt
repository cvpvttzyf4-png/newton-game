
NEWTON APPLE DODGE - iPHONE READY

Files included:
- index.html
- style.css
- game.js

Features:
- Touch controls for iPhone
- Retro arcade visuals
- 80s-inspired chiptune soundtrack
- Retro sound effects
- Responsive mobile layout

HOW TO TURN INTO AN iPHONE APP:

OPTION 1 (EASIEST)
Upload the files to:
https://www.webintoapp.com/
or
https://www.convertify.app/

These services create an iPhone app package from your game.

OPTION 2
Use Capacitor or Cordova to package it into an iOS app using Xcode on a Mac.

IMPORTANT:
The music is original retro arcade-inspired audio and does not reproduce copyrighted Queen melodies.
